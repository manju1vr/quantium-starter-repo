# Task 2 Model Answer
