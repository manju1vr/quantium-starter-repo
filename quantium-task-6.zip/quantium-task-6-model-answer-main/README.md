# Task 6 Model Answer
