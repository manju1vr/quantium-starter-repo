# Task 1 Model Answer
